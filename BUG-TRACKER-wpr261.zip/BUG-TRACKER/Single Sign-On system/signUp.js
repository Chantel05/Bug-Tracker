
function signUp() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    if (!username || !password) {
        alert("Please fill in all fields!");
        return;
    }

    // Retrieves credentials from local storage
    let storedCredentials = JSON.parse(localStorage.getItem("credentials")) || [];

    // Checks if the username already exists
    let isExistingUser = storedCredentials.some(function (credentials) {
        return credentials.username === username;
    });

    if (isExistingUser) {
        alert("Username exists, Welcome to the dashboard");
        
    }

    //stored credentials array
    storedCredentials.push({ username: username, password: password });

    // stores updated credentials
    localStorage.setItem("credentials", JSON.stringify(storedCredentials));

    alert("Welcome new user, your Sign up is successful!");
    window.location.href = "BugTrackerPage.html";
    // redirects to the dashboard
}


