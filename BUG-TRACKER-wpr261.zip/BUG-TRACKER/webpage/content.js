window.onload = function() {
    showContent('bug-Report'); // Call showContent with the desired option on page load
};


function showContent(option) {
    let content = '';

    if (option === 'Profile') {
        content = 'Content for Profile option';
    } else if (option === 'Projects') {
        content = 'Content for Projects option';
    } else if (option === 'index') {
        content = 'Content for index option';
    }

    let dashboardContent = document.getElementById('dashboard-content');
    dashboardContent.innerHTML = content;
}
function showContent(option) {
    let content = '';

    if (option === 'Profile') {
        content = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Developer Profile</title>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        </head>
        <body>
            <center>
                <div class="container">
                    <h3>Add Developer</h3>
                    <div class="jumbotron">
                        <form id="issueInputForm">
                            <!--Upload Image for Profile Picture-->
                            <section class="form-group">
                                <div class="form-group">
                                    <img id="propic" src="profile.png" alt="Profile" width="150px">
                                </div>
                                <div class="form-group">
                                    <input type="file" onchange="readURL(this);" class="form-control">
                                </div>
                            </section>
                    
                        <!--Display Random ID for the Dev to be Entered-->
                        <div class="form-group">
                            <input type="text" id="firstname" placeholder="First Name" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" id="lastname" placeholder="Last Name" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" id="username" placeholder="User Name" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="email" id="email" placeholder="Email Address" class="form-control">
                        </div>
                        <div class="form-group">
                            <button id="add-user" class="btn btn-primary" onclick="submitUser()">Add Developer</button>
                        </div>
                        </form>
                    </div>
                    <!--Display Added Users Here-->
                    
                </div>
                <div class="col-lg-12">
                    <div id="issuesList">
                    </div>
                </div>
            </center>
                 <!--Modal To Catch Empty Fields-->
          <div class="modal fade" id="emptyField" tabindex="-1" role="dialog" aria-labelledby="emptyFieldLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="emptyFieldLabel">Invalid Input!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  Please provide the desciption of the issue and also the person name who you want to assign the issue.
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
          <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>
          <!-- Latest compiled and minified JavaScript -->
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
                <script src="profile.js"></script>
        </body>
        </html>
            
        

        
       
    `;
    } else if (option === 'Projects') {
        content = `
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Projects.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet' crossorigin="anonymous" referrerpolicy="non-referrer" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Projects</title>
</head>
<body>
    <div class="table">
        <div class="table_header">
            <h1>Projects</h1>
            <button type="submit" id="1btn" onclick="backToDashboard()" class="back-btn">Back</button>
            <script>
                function backToDashboard() {
                    alert("Back to the Dashboard");
                    window.location.href = "BugTrackerPage.html";
                }
            </script>
            <div class="upper-btn-box">
                <div class="left-box">
                    <button id="add-btn" style="background-color: rgb(61, 65, 99);"><i class="fa fa-plus"></i>&nbsp; Create Project</button>
                </div>
                <div class="right-box">
                    <i class="fa fa-search"></i>
                    <input type="text" id="project" placeholder="Search Project">
                    <button id="search-btn" style="background-color: rgb(61, 65, 99);">Search</button>
                </div>
            </div>
        </div>
    </div>
    <div class="table_section">
        <table>
            <thead>
                <tr>
                    <th>Project Name</th>
                    <th>Project ID</th>
                    <th>Assign Developer</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="table-data">
                <tr>
                    <td>Sage Accounting</td>
                    <td>95874</td>
                    <td>Will Smith</td>
                    <td>Pending</td>
                    <td>
                        <button><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
                <tr>
                    <td> Safety and Security</td>
                    <td>85741</td>
                    <td>John Wick</td>
                    <td>Pending</td>
                    <td>
                        <button><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
                <tr>
                    <td>Data Encryption</td>
                    <td>74859</td>
                    <td>Chris Brown</td>
                    <td>Complete</td>
                    <td>
                        <button><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
                <tr>
                    <td>Reservations</td>
                    <td>84671</td>
                    <td>Mzekezeke</td>
                    <td>Complete</td>
                    <td>
                        <button><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
                <tr>
                    <td>Communications</td>
                    <td>84671</td>
                    <td>Mzekezeke</td>
                    <td>Pending</td>
                    <td>
                        <button><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
                <tr>
                    <td>Waste management</td>
                    <td>74859</td>
                    <td>Chris Brown</td>
                    <td>Complete</td>
                    <td>
                        <button><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
                <tr>
                    <td>End-User</td>
                    <td>85741</td>
                    <td>John Wick</td>
                    <td>Complete</td>
                    <td>
                        <button><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
                <tr>
                    <td>Public Relations</td>
                    <td>95874</td>
                    <td>Will Smith</td>
                    <td>Complete</td>
                    <td>
                        <button><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div> 
    <div class="modal">
        <i class="fa fa-times-circle close-icon"></i>
        <div class="left-modal">
            <h3>Create Project</h3>
            <br> 
            <div class="input-box">
                <label for="name">Project Name</label>
                <input type="text" required id="name">
            </div>
            <form id="save-form">
                <div class="input-box">
                    <label for="id">Project ID</label><br>
                    <input type="text" required id="id">
                </div>
                <div class="input-box">
                    <label for="assign">Assign Developer</label><br>
                    <input type="text" required id="assign">
                </div> 
                <div class="input-box">
                    <label for="status">Status</label><br>
                    <input type="radio" name="status" value="pending" checked> Pending
                    <input type="radio" name="status" value="complete"> Complete
                    <input type="radio" name="status" value="backlog"> Backlog
                </div> 
                <div class="input-box">
                    <button id="save">Save</button>
                </div>
            </form>
        </div>
    </div>
    <script src="Projects.js"></script>
</body>
</html>

        
        
        `;
    } else if (option === 'web-Developers') {
        content= `
        
        <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

                <link rel="stylesheet" href="peoplecontents.css">
                
                <title>Create People</title>
            </head>
            <body>
                <div class="container">
                    <div class="content">
                        <a href="#" class="brand">
                          <i class='bx bx-bot'></i>

                        </a>
                        <h2>People</h2>
                        
                        <img src= "people.gif" alt="">
                        <p> Welcome to the people page.

</p>
                        <p>
This is where the people responsible for the projects will be created. The CWW member who made this part is Rivoningo. Press the view people button to see the page.
                        </p>
                        <button type="submit" id="btn" onclick="openViewPeople()">View People</button>
                    </div>
                </div>
                
            </body>
            </html>


        
        
        
        
        
        `;
    }
 else if (option === 'analytics') {
    content = `

    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

        <link rel="stylesheet" href="analyticscontent.css">
        
        <title>Bug Report</title>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <a href="#" class="brand">
                   <i class='bx bx-doughnut-chart' ></i>
                </a>
                <h2>Analytics</h2>
                
                <img src="analytics.gif" alt="Bug Detector Image">
                <p>
                     Analytics plays a vital role in our society. They provide can provide valuable insights which could be used for decision making,
   improving operations and generating revenue. In this case, to provide more accuracy in the data of the projects statuses, pie charts will be used 
   to display the data of the number of projects completed themselves. Press the button below to view the analytics page.

                </p>
                <button type="submit" id="btn" onclick="openAnalytics()">View Analytics</button>
            </div>
        </div>
       

     
        
    </body>
    </html>


    

    
    `;
}
 else if (option === 'team') {
    content = `
    
    <!DOCTYPE html>
    <html>
    <head>
        <link rel="stylesheet" type="text/css" href="team.css">
       
    </head>
    <body>
        <h1>Meet our Team</h1>
        <section id="team-profiles">
    
            <div class="profile">
                <img src="MicrosoftTeams-image (5).png" alt="Profile 1">
                <h2>Kimberly</h2>
                <p>Position: Web Developer</p>
                <p>Experience: 5 years</p>
                <button onclick="openProfile('kimberly')">View Profile</button>
            </div>
    
            <div class="profile">
                <img src="MicrosoftTeams-image (4).png" alt="Profile 2">
                <h2>Kuhlekonke</h2>
                <p>Position: UX Designer</p>
                <p>Experience: 8 years</p>
                <button onclick="openProfile('kuhlekonke')">View Profile</button>
            </div>
    
            <div class="profile">
                <img src="MicrosoftTeams-image (7).png" alt="Profile 3">
                <h2>Nicolaas</h2>
                <p>Position: Software Engineer</p>
                <p>Experience: 3 years</p>
                <button onclick="openProfile('nicolaas')">View Profile</button>
            </div>
    
            <div class="profile">
                <img src="MicrosoftTeams-image (3).png" alt="Profile 3">
                <h2>Rivoningo</h2>
                <p>Position: Software Engineer</p>
                <p>Experience: 3 years</p>
                <button onclick="openProfile('rivoningo')">View Profile</button>
            </div>
    
        </section>
        <script src="team.js"></script> 
    </body>
    </html>
    

    
    
    `;
}

     dashboardContent = document.getElementById('dashboard-content');
    dashboardContent.innerHTML = content;
}

 
 
 