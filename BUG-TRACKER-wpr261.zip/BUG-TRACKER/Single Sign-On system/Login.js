

document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form submission

  // Get the entered username and password
  let username = document.getElementById('username').value;
  let password = document.getElementById('password').value;

  // Perform authentication logic
  if (username === 'admin' && password === 'password') {
    alert('Login successful! You are now logged in as the admin.'); // Show success message

    // Save the logged-in user information (e.g., in local storage or session storage)
    // For example:
    localStorage.setItem('loggedInUser', username);
    
    // Redirect to the dashboard of the Bug Tracking system
     window.location.href = 'dashboard.html';

    // Redirect to the admin dashboard or desired page
    window.location.href = 'admin-dashboard.html';
  } else {
    showError('Invalid credentials! Please try again.'); // Show error message
  }
});

function showError(message) {
  let errorElement = document.createElement('p');
  errorElement.classList.add('error-message');
  errorElement.textContent = message;
  document.getElementById('loginForm').appendChild(errorElement);

  // Clear the error message after 3 seconds
  setTimeout(function() {
    errorElement.remove();
  }, 3000);
}







/*
function injectSvgSprite(path) {
      
    var ajax = new XMLHttpRequest();
    ajax.open("GET", path, true);
    ajax.send();
    ajax.onload = function(e) {
    var div = document.createElement("div");
    div.className = 'd-none';
    div.innerHTML = ajax.responseText;
    document.body.insertBefore(div, document.body.childNodes[0]);
    }
}
// this is set to BootstrapTemple website as you cannot 
// inject local SVG sprite (using only 'icons/orion-svg-sprite.svg' path)
// while using file:// protocol
// pls don't forget to change to your domain :)
injectSvgSprite('https://bootstraptemple.com/files/icons/orion-svg-sprite.svg'); 
*/


