function openProfile(profile) {
    switch (profile) {
        case 'thembelihle':
            window.location.href = 'thembelihle.html';
            break;
        case 'paul':
            window.location.href = 'paul.html';
            break;
        case 'zwibuya':
            window.location.href = 'zwibuya.html';
            break;
        case 'yolanda':
            window.location.href = 'yolanda.html';
            break;
        case 'mrt':
            window.location.href = 'mrt.html';
            case 'tumelo':
                window.location.href = 'tumelo.html';
        default:
            break;
    }
}
