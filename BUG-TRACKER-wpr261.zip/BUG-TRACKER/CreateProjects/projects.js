const addBtn = document.querySelector("#add-btn");
const modal = document.querySelector(".modal");
const closeBtn = document.querySelector(".close-icon");
addBtn.onclick = function() {
    modal.classList.add("active");
};
closeBtn.addEventListener("click", () => {
    modal.classList.remove("active");
});

const userData = [];
const nameE1 = document.getElementById("name");
const idE1 = document.querySelector("#id");
const assignE1 = document.getElementById("assign");
const statusE1 = document.querySelectorAll("input[name='status']");
const saveBtn = document.querySelector("#save");
const saveForm = document.querySelector("#save-form");

saveForm.onsubmit = function(e) {
    e.preventDefault();
    saveData();
    closeBtn.click();
};

if (localStorage.getItem("userData") !== null) {
    userData = JSON.parse(localStorage.getItem("userData"));
}

function saveData() {
    userData.push({
        name: nameE1.value,
        id: idE1.value,
        assign: assignE1.value,
        status: document.querySelector("input[name='status']:checked").value
    });
    var userString = JSON.stringify(userData);
    localStorage.setItem("userData", userString);
    swal("Approved", "Project Created!", "success");
    getDataFromLocalStorage();
}

let tableData = document.querySelector("#table-data");

function getDataFromLocalStorage() {
    tableData.innerHTML = "";
    userData.forEach((data, index) => {
        tableData.innerHTML += `
            <tr index="${index}">
                <td>${data.name}</td>
                <td>${data.id}</td>
                <td>${data.assign}</td>
                <td>${data.status}</td>
                <td>
                    <button class="del-btn"><i class="fa fa-trash"></i></button>
                </td>
            </tr>`;
    });

    let allDelBtn = document.querySelectorAll(".del-btn");
    for (var i = 0; i < allDelBtn.length; i++) {
        allDelBtn[i].onclick = function() {
            let tr = this.parentElement.parentElement;
            let id = tr.getAttribute("index");
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this file",
                icon: "warning",
                buttons: true,
                dangerMode: true
            }).then((willDelete) => {
                if (willDelete) {
                    userData.splice(id, 1);
                    localStorage.setItem("userData", JSON.stringify(userData));
                    tr.remove();
                    swal("File deleted!", {
                        icon: "success"
                    });
                } else {
                    swal("File is safe!");
                }
            });
        };
    }

    let allEdit = document.querySelectorAll(".edit-btn");
    for (let i = 0; i < allEdit.length; i++) {
        allEdit[i].onclick = function() {
            let tr = this.parentElement.parentElement;
            let td = tr.getElementsByTagName("td");
            let index = tr.getAttribute("index");
        };
    }
}

getDataFromLocalStorage();

