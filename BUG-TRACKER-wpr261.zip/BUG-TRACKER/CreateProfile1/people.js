var registerForm = document.querySelector("#register-form");
var allInputs = registerForm.querySelectorAll("input");
var addBtn = document.querySelector("#add-btn");
var modal = document.querySelector(".modal");
var closeBtn = document.querySelector(".close-icon");

addBtn.onclick = function () {
  modal.classList.add("active");
};

closeBtn.addEventListener("click", () => {
  modal.classList.remove("active");
});

const userData = [];
const idEl = document.getElementById("id");
const nameEl = document.querySelector("#name");
const surnameEl = document.getElementById("surname");
const emailEl = document.querySelector("#email");
const usernameEl = document.getElementById("username");
const profilePic = document.querySelector("#profile-pic");
const imgUrl = profilePic.src || "BUG-TRACKER/image/picbox.jpg";

registerForm.onsubmit = function (e) {
  e.preventDefault();
  registerData();
  registerForm.reset();
  closeBtn.click();
};

if (localStorage.getItem("userData") !== null) {
  userData = JSON.parse(localStorage.getItem("userData"));
}

function registerData() {
  userData.push({
    id: idEl.value,
    name: nameEl.value,
    surname: surnameEl.value,
    email: emailEl.value,
    username: usernameEl.value,
    profilePic: imgUrl,
  });

  localStorage.setItem("userData", JSON.stringify(userData));
  swal("Saved", "Profile Created!", "success");
  getDataFromLocalStorage();
}

var tableData = document.querySelector("#table-data");

function getDataFromLocalStorage() {
  tableData.innerHTML = "";

  userData.forEach((data, index) => {
    tableData.innerHTML += `
      <tr index='${index}'>
        <td>${index + 1}</td>
        <td>${data.id}</td>
        <td>${data.name}</td>
        <td>${data.surname}</td>
        <td>${data.email}</td>
        <td>${data.username}</td>
        <td><img src="${data.profilePic}" width="40"></td>
        <td>
          <button class="view-btn"><i class="fa fa-eye"></i></button>
          <button class="del-btn" style="background-color: #EE534F;"><i class="fa fa-trash"></i></button>
        </td>
      </tr>`;
  });

  let allDelBtn = document.querySelectorAll(".del-btn");
  for (let i = 0; i < allDelBtn.length; i++) {
    allDelBtn[i].onclick = function () {
      let tr = this.parentElement.parentElement;
      let id = tr.getAttribute("index");
      swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover this file",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          userData.splice(id, 1);
          localStorage.setItem("userData", JSON.stringify(userData));
          tr.remove();
          swal("File deleted!", {
            icon: "success",
          });
        } else {
          swal("File is safe!");
        }
      });
    };
  }

  let allViewBtn = document.querySelectorAll(".view-btn");
  for (let i = 0; i < allViewBtn.length; i++) {
    allViewBtn[i].onclick = function () {
      let tr = this.parentElement.parentElement;
      let id = tr.getAttribute("index");

      // Perform your view action here
      console.log("Viewing profile with index:", id);
    };
  }
}

getDataFromLocalStorage();

let uploadPic = document.querySelector("#upload-field");
uploadPic.onchange = function () {
  if (uploadPic.files[0].size < 1000000) {
    let fReader = new FileReader();
    fReader.onload = function (e) {
      var profilePic = document.querySelector("#profile-pic");
      profilePic.src = e.target.result;
      console.log(e.target.result);
    };
    fReader.readAsDataURL(uploadPic.files[0]);
  } else {
    alert("File size is too large");
  }
};

  

